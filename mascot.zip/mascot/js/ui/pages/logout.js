/*
 *	logout.js
 *
 *	This script simply redirects users from the
 *	silly logout landing page to the login page.
 *
 */
 
window.location = loginURL;