/*
 *	phone-numbers.js
 *
 *	Created by Moshe Berman on August 14, 2013
 *
 *	This file maps out phone numbers by school.
 *
 */

/****
 *	Bursar's Office - first by school, then dictionary of all of them
 ****/

 var bursarPhoneBrooklyn = "";

 var bursarPhoneNumbers = {"BKL" : bursarPhoneBrooklyn};

/****
 *	Registrar's office - first by school, then dictionary of all of them
 ****/

 var registrarPhoneBrooklyn = "";

 var registrarPhoneNumbers = {"BKL" : bursarPhoneBrooklyn};
