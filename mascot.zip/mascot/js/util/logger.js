/*
 *	Created by Moshe Berman on August 12, 2013
 *
 *	Logger.js simply logs messages to the console
 *	but may do other things in the future.
 */

function log(message) {
	console.log(message);
}